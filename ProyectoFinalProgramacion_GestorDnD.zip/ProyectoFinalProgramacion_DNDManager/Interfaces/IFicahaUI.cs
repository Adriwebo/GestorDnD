﻿using ProyectoFinalProgramacion_DNDManager.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.UI
{
    public interface IFichaUI
    {
        void MostrarFicha(Personaje p);
    }
}
