﻿
using Microsoft.EntityFrameworkCore;
using ProyectoFinalProgramacion_DNDManager.Data;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using ProyectoFinalProgramacion_DNDManager.Servicios;

class Program
{
    static void Main()
    {
        // Cambiar el color de fondo y de texto
        Console.BackgroundColor = ConsoleColor.DarkMagenta;
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Clear();

        Console.OutputEncoding = System.Text.Encoding.UTF8;

        using var context = new DnDContext();
        context.Database.EnsureCreated(); // Crea la base de datos si no existe

        var usuariosServ = new UsuariosServ(context);
        var campanyaServ = new CampanyaServ(context);
        var partidaServ = new PartidaServ(context);
        var personajeServ = new PersonajeServ(context, usuariosServ.UsuarioActual!);

        MostrarMenuInicio(usuariosServ, campanyaServ, partidaServ, personajeServ);

    }

    static void MostrarMenuInicio(UsuariosServ usuariosServ, CampanyaServ campanyaServ, PartidaServ partidaServ, PersonajeServ personajeServ)
    {
        bool salir = false;

        do
        {
            Console.Clear();

            // Menú principal centrado y alineado
            string[] opciones = new string[]
                {
                    "1. Registrar usuario",
                    "2. Iniciar sesión",
                    "3. Exportar datos a JSON",
                    "4. Ver usuario actual",
                    "5. Cerrar sesión",
                    "6. Salir"
                };


            PrintBlockCentered("=== GESTOR D&D ===", opciones);
            PrintCentered("Opción: ", false);
            string? opcion = Console.ReadLine();

            Console.Clear();

            switch (opcion)
            {
                case "1":
                    RegistrarUsuario(usuariosServ);
                    break;
                case "2":
                    IniciarSesion(usuariosServ, campanyaServ);
                    break;
                case "3":
                    ExportarDatos(usuariosServ, campanyaServ, partidaServ, personajeServ);
                    break;             
                case "4":
                    VerUsuarioActual(usuariosServ);
                    break;
                case "5":
                    CerrarSesion(usuariosServ);
                    break;
                case "6":
                    salir = true;
                    break;
                default:
                    PrintCentered("[ERROR] Opción inválida.");
                    break;
            }

            if (!salir)
            {
                PrintCentered("\nPulsa una tecla para continuar...");
                Console.ReadKey();
            }
        } while (!salir);
    }

    /************** Funciones de Menú de Inicio ***************/
    static void RegistrarUsuario(UsuariosServ usuariosServ)
    {
        PrintCentered("Nombre de usuario: ", false);
        string nuevoNombre = Console.ReadLine()!;
        PrintCentered("Contraseña: ", false);
        string nuevaPass = Console.ReadLine()!;
        bool registrado = usuariosServ.RegistrarUsuario(nuevoNombre, nuevaPass);
        PrintCentered(registrado
            ? "[ÉXITO] Usuario registrado correctamente."
            : "[ERROR] Ese usuario ya existe.");
        usuariosServ.MostrarUsuariosRegistrados();
    }
    static void IniciarSesion(UsuariosServ usuariosServ, CampanyaServ campanyaServ)
    {
        PrintCentered("Nombre de usuario: ", false);
        string nombre = Console.ReadLine()!;
        PrintCentered("Contraseña: ", false);
        string pass = Console.ReadLine()!;
        bool login = usuariosServ.IniciarSesion(nombre, pass);

        if (login)
        {
            PrintCentered($"[ÉXITO] Bienvenido, {usuariosServ.UsuarioActual!.Nombre}.");
            Console.ReadKey();
            MostrarMenuUsuarioAutenticado(usuariosServ, campanyaServ); // Redirección al menú logueado
        }
        else
        {
            PrintCentered("[ERROR] Usuario o contraseña incorrectos.");
        }
    }

    // Exportación de la base de datos a archivos JSON
    static void ExportarDatos(UsuariosServ usuariosServ, CampanyaServ campanyaServ, PartidaServ partidaServ, PersonajeServ personajeServ)
    {
        AlmacenamientoJson.GuardarUsuarios(usuariosServ.ObtenerTodosUsuarios());
        AlmacenamientoJson.GuardarCampanyas(campanyaServ.ObtenerTodasCampanyas());
        AlmacenamientoJson.GuardarPartidas(partidaServ.ObtenerTodasPartidas());
        AlmacenamientoJson.GuardarPersonajes(personajeServ.ObtenerTodosPersonajes());
        PrintCentered("Datos exportados a JSON correctamente.");
    }


    static void VerUsuarioActual(UsuariosServ usuariosServ)
    {
        if (usuariosServ.EstaAutenticado())
            PrintCentered($"Usuario actual: {usuariosServ.UsuarioActual!.Nombre}");
        else
            PrintCentered("No hay sesión iniciada.");
    }
    static void CerrarSesion(UsuariosServ usuariosServ)
    {
        usuariosServ.CerrarSesion();
        PrintCentered("Sesión cerrada.");
    }
    /******************************************************************/


    //Menú con sesión iniciada
    static void MostrarMenuUsuarioAutenticado(UsuariosServ usuariosServ, CampanyaServ campanyaServ)
    {
        Console.Clear();
        bool salir = false;

        while (!salir)
        {
            Console.Clear();
            string[] opcionesUsuario = new string[]
            {
            "1. Gestionar campañas",
            "2. Gestionar partidas",
            "3. Gestionar personajes",          
            "4. Ver usuario actual",
            "5. Cerrar sesión",
            "6. Salir"
            };

            PrintBlockCentered("=== GESTOR D&D ===", opcionesUsuario);
            PrintCentered("Opción: ", false);
            string? opcion = Console.ReadLine();

            Console.Clear();

            switch (opcion)
            { 
                case "1":
                    using (var contextoCamp = new DnDContext())
                    {
                        GestionarCampanyas(contextoCamp);
                    }
                    break;

                case "2":
                    using (var contextoPartida = new DnDContext())
                    {
                        var partidaServ = new PartidaServ(contextoPartida);
                        GestionarPartidas(partidaServ);
                    }
                    break;

                case "3":
                    using (var contextoPer = new DnDContext())
                    {
                        var personajeServ = new PersonajeServ(contextoPer, usuariosServ.UsuarioActual!);
                        GestionarPersonajes(personajeServ, usuariosServ);
                    }
                    break;
                case "4":
                    Console.WriteLine($"Usuario: {usuariosServ.UsuarioActual!.Nombre}");
                    break;

                case "5":
                    usuariosServ.CerrarSesion();
                    Console.WriteLine("Sesión cerrada.");
                    salir = true;
                    break;

                case "6":
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }

            Console.WriteLine("\nPulsa una tecla para continuar...");
            Console.ReadKey();

        }

    }

    // Menú para gestión de campañas
    static void GestionarCampanyas(DnDContext context)
    {
        var campanyaServ = new CampanyaServ(context);
        bool volver = false;

        while (!volver)
        {
            Console.Clear();
            string[] opciones = new string[]
            {
            "1. Crear nueva campaña",
            "2. Ver campañas existentes",
            "3. Buscar campañas",
            "4. Editar campaña",
            "5. Eliminar campaña",
            "6. Volver al menú principal"
            };

            PrintBlockCentered("=== GESTIÓN DE CAMPAÑAS ===", opciones);
            PrintCentered("Opción: ", false);
            string? opcion = Console.ReadLine();
            Console.Clear();

            switch (opcion)
            {
                case "1":
                    campanyaServ.CrearCampanya();
                    break;
                case "2":
                    campanyaServ.VerCampanyasYPartidas();
                    Console.WriteLine("\nPulsa una tecla para continuar...");
                    Console.ReadKey();
                    break;
                case "3":
                    campanyaServ.BuscarCampanyasFiltrado();
                    Console.WriteLine("\nPulsa una tecla para continuar...");
                    Console.ReadKey();
                    break;
                case "4":
                    campanyaServ.EditarCampanya();
                    Console.WriteLine("\nPulsa una tecla para continuar...");
                    Console.ReadKey();
                    break;
                case "5":
                    campanyaServ.EliminarCampanya();
                    Console.WriteLine("\nPulsa una tecla para continuar...");
                    Console.ReadKey();
                    break;
                case "6":
                    volver = true;
                    break;
                default:
                    PrintCentered("Opción inválida.");
                    Console.ReadKey();
                    break;
            }
        }
    }

    // Menú para gestionar partidas
    static void GestionarPartidas(PartidaServ partidaServ)
    {
        using var context = new DnDContext();
        var campanyas = context.Campanyas.Include(c => c.Partidas).ToList();

        if (!campanyas.Any())
        {
            PrintCentered("No hay campañas disponibles.");
            Console.ReadKey();
            return;
        }

        Console.Clear();
        PrintCentered("Selecciona una campaña:\n");
        for (int i = 0; i < campanyas.Count; i++)
        {
            PrintCentered($"{i + 1}. {campanyas[i].Nombre}");
        }
        PrintCentered("\nOpción: ", false);

        if (!int.TryParse(Console.ReadLine(), out int seleccion) || seleccion < 1 || seleccion > campanyas.Count)
        {
            PrintCentered("Selección inválida.");
            Console.ReadKey();
            return;
        }

        int campanyaId = campanyas[seleccion - 1].Id;
        bool volver = false;

        while (!volver)
        {
            Console.Clear();
            string[] opciones = new string[]
            {
                "1. Crear nueva partida",
                "2. Ver partidas existentes",
                "3. Buscar partidas",
                "4. Editar partida",
                "5. Eliminar partida",
                "6. Volver"
            };

            PrintBlockCentered("=== GESTIÓN DE PARTIDAS ===", opciones);
            PrintCentered("Opción: ", false);
            string? opcion = Console.ReadLine();
            Console.Clear();

            switch (opcion)
            {
                case "1":
                    partidaServ.CrearPartida(campanyaId);
                    break;
                case "2":
                    partidaServ.VerPartidas(campanyaId);
                    break;
                case "3":
                    partidaServ.BuscarPartidasFiltrado();
                    break;
                case "4":
                    partidaServ.EditarPartida(campanyaId);
                    break;
                case "5":
                    partidaServ.EliminarPartida(campanyaId);
                    break;
                case "6":
                    volver = true;
                    break;
                default:
                    PrintCentered("Opción inválida.");
                    break;
            }

            if (!volver)
            {
                PrintCentered("\nPulsa una tecla para continuar...");
                Console.ReadKey();
            }
        }
    }

    // Menú para gestionar personajes
    static void GestionarPersonajes(PersonajeServ personajeServ, UsuariosServ usuariosServ)
    {
        bool volver = false;

        while (!volver)
        {
            Console.Clear();
            string[] opciones = new string[]
            {
            "1. Crear nuevo personaje",
            "2. Ver personajes del usuario",
            "3. Ver todos los personajes",
            "4. Buscar personajes",
            "5. Editar personaje",
            "6. Eliminar personaje",
            "7. Exportar personaje a PDF",
            "8. Volver"
            };

            PrintBlockCentered("=== GESTIÓN DE PERSONAJES ===", opciones);
            PrintCentered("Opción: ", false);
            string? opcion = Console.ReadLine();
            Console.Clear();

            switch (opcion)
            {
                case "1":
                    personajeServ.CrearPersonaje(usuariosServ.UsuarioActual);
                    break;
                case "2":
                    personajeServ.VerPersonajes();
                    break;
                case "3":
                    personajeServ.VerPersonajesPublicos();
                    break;
                case "4":
                    personajeServ.BuscarPersonajesFiltrado();
                    break;
                case "5":
                    personajeServ.EditarPersonaje();
                    break;
                case "6":
                    personajeServ.EliminarPersonaje();
                    break;
                case "7":
                    personajeServ.ExportarPersonajeAPDF();
                    break;
                case "8":
                    volver = true;
                    break;
                default:
                    PrintCentered("Opción inválida.");
                    break;
            }

            if (!volver)
            {
                PrintCentered("\nPulsa una tecla para continuar...");
                Console.ReadKey();
            }
        }
    }



    // Método para imprimir un texto centrado
    static void PrintCentered(string texto, bool nuevaLinea = true)
    {
        int consoleWidth = Console.WindowWidth;
        int padding = (consoleWidth - texto.Length) / 2;
        if (padding < 0) padding = 0;
        Console.SetCursorPosition(padding, Console.CursorTop);
        if (nuevaLinea)
            Console.WriteLine(texto);
        else
            Console.Write(texto);
    }

    // Método para imprimir un bloque de texto centrado con sangría alineada
    static void PrintBlockCentered(string titulo, string[] menu)
    {
        // Buscar el texto más largo para centrar el bloque completo
        int maxLength = menu.Max(l => l.Length);
        int consoleWidth = Console.WindowWidth;
        int blockPadding = (consoleWidth - maxLength) / 2;

        // Título centrado
        PrintCentered(titulo);

        // Líneas alineadas
        foreach (var linea in menu)
        {
            Console.SetCursorPosition(blockPadding, Console.CursorTop);
            Console.WriteLine(linea);
        }
    }



}





