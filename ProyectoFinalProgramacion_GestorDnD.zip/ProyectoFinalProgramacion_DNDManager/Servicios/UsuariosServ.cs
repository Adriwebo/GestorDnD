﻿using ProyectoFinalProgramacion_DNDManager.Data;
using ProyectoFinalProgramacion_DNDManager.Modelos;

namespace ProyectoFinalProgramacion_DNDManager.Servicios
{
    public class UsuariosServ
    {
        private readonly DnDContext _context;
        private Usuario? _usuarioActual;

        public UsuariosServ(DnDContext context)
        {
            _context = context;
        }

        public Usuario? UsuarioActual => _usuarioActual;

        public bool RegistrarUsuario(string nombre, string contraseña)
        {
            if (_context.Usuarios.Any(u => u.Nombre == nombre))
                return false;

            var nuevoUsuario = new Usuario { Nombre = nombre, Contraseña = contraseña };
            _context.Usuarios.Add(nuevoUsuario);
            _context.SaveChanges();
            return true;
        }

        public bool IniciarSesion(string nombre, string contraseña)
        {
            var usuario = _context.Usuarios
                .FirstOrDefault(u => u.Nombre == nombre && u.Contraseña == contraseña);

            if (usuario == null)
                return false;

            _usuarioActual = usuario;
            return true;
        }

        public void CerrarSesion()
        {
            _usuarioActual = null;
        }

        public bool EstaAutenticado() => _usuarioActual != null;

        public void MostrarUsuariosRegistrados()
        {
            var usuarios = _context.Usuarios.ToList();
            Console.WriteLine("\nUsuarios registrados actualmente:");
            foreach (var u in usuarios)
            {
                Console.WriteLine($"- {u.Nombre}");
            }
        }

        public List<Usuario> ObtenerTodosUsuarios()
        {
            return _context.Usuarios.ToList();
        }

        
    }
}
