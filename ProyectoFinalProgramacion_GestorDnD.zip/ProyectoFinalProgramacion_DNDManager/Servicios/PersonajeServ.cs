﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProyectoFinalProgramacion_DNDManager.Data;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using ProyectoFinalProgramacion_DNDManager.UI;

namespace ProyectoFinalProgramacion_DNDManager.Servicios
{
    public class PersonajeServ
    {
        private readonly DnDContext _context;
        private readonly Usuario _usuarioActual;

        public PersonajeServ(DnDContext context, Usuario usuarioActual)
        {
            _context = context;
            _usuarioActual = usuarioActual;
        }

        public void CrearPersonaje(Usuario usuario)
        {
            var usuarioAdjunto = _context.Usuarios.Find(usuario.Id);
            if (usuarioAdjunto == null)
            {
                PrintCentered("[ERROR] El usuario no existe en la base de datos.");
                Console.ReadKey();
                return;
            }

            var personaje = new Personaje(
                nombre: "",
                clase: "",
                nivel: 1,
                descripcion: "",
                vida: 0,
                armadura: 0,
                fue: 0,
                des: 0,
                con: 0,
                @int: 0,
                sab: 0,
                car: 0,
                acciones: new(),
                accionesAdicionales: new(),
                accionesLegendarias: new(),
                accionesGratuitas: new(),
                accionesMovimiento: new(),
                accionesGuarida: new(),
                reacciones: new(),
                pasivas: new(),
                resistencias: new(),
                auras: new(),
                transformaciones: new(),
                dotes: new(),
                objetos: new(),
                sentidos: new(),
                hechizos: new(),
                usuarioId: usuarioAdjunto.Id,
                campanyas: new(),
                rasgos: new()
            );

            bool completado = false;

            while (!completado)
            {
                Console.Clear();
                PrintCentered("=== CREACIÓN DE PERSONAJE ===");

                // Cambiar el color de fondo y de texto
                Console.BackgroundColor = ConsoleColor.DarkMagenta;
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Clear();


                // Calcular el padding para centrar el bloque del menú
                int maxLength = 30; // Longitud estimada máxima de las líneas
                int blockPadding = (Console.WindowWidth - maxLength) / 2;

                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                PrintCentered("\nProgreso:");

                // Mostrar cada paso centrado usando MostrarEstadoPaso
                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                MostrarEstadoPaso("1. Datos básicos", personaje.Nombre != "");

                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                MostrarEstadoPaso("2. Atributos principales", personaje.Fue > 0);

                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                MostrarEstadoPaso("3. Rasgos y habilidades", personaje.Rasgos.Any());

                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                MostrarEstadoPaso("4. Vincular campañas", personaje.Campanyas.Any());

                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                Console.WriteLine("5. Finalizar creación");

                // Centrar la solicitud de entrada
                string prompt = "\nSeleccione qué desea editar: ";
                Console.SetCursorPosition((Console.WindowWidth - prompt.Length) / 2, Console.CursorTop);
                Console.Write(prompt);
                var opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        EditarDatosBasicos(personaje);
                        break;
                    case "2":
                        EditarAtributos(personaje);
                        break;
                    case "3":
                        MenuRasgos(personaje);
                        break;
                    case "4":
                        VincularCampanyas(personaje);
                        break;
                    case "5":
                        if (ValidarPersonajeCompleto(personaje))
                        {
                            try
                            {
                                _context.Personajes.Add(personaje);
                                _context.SaveChanges();
                                PrintCentered($"\nPersonaje '{personaje.Nombre}' creado exitosamente.");
                                Console.ReadKey();
                                completado = true;
                            }
                            catch (DbUpdateException ex)
                            {
                                PrintCentered("\nError al guardar el personaje en la base de datos.");
                                Console.WriteLine("Detalles:");
                                Console.WriteLine(ex.InnerException?.Message ?? ex.Message);
                                Console.ReadKey();
                                completado = false;
                            }
                            catch (Exception ex)
                            {
                                PrintCentered("\nError inesperado.");
                                Console.WriteLine("Detalles:");
                                Console.WriteLine(ex.Message);
                                Console.ReadKey();
                                completado = false;
                            }
                        }
                        else
                        {
                            PrintCentered("\nEl personaje no está completo. Faltan datos obligatorios.");
                            Console.ReadKey();
                        }
                        break;

                    default:
                        PrintCentered("Opción no válida.");
                        Console.ReadKey();
                        break;
                }
            }
        }

        private void EditarDatosBasicos(Personaje personaje)
        {
            Console.Clear();
            PrintCentered("=== DATOS BÁSICOS ===");

            personaje.Nombre = PedirDato("Nombre del personaje", personaje.Nombre);
            personaje.Clase = PedirDato("Clase", personaje.Clase);
            personaje.Nivel = PedirNumero("Nivel", personaje.Nivel, 1, 50);
            personaje.Descripcion = PedirDato("Descripción", personaje.Descripcion);
            personaje.Vida = PedirNumero("Puntos de vida", personaje.Vida, 1, 33333);
            personaje.Armadura = PedirNumero("Clase de Armadura (CA)", personaje.Armadura, 8, 200);
            personaje.Competencia = CalcularCompetencia(personaje.Nivel);

            PrintCentered("\nDatos básicos actualizados correctamente.");
            Console.ReadKey();
        }

        private void EditarAtributos(Personaje personaje)
        {
            Console.Clear();
            PrintCentered("=== ATRIBUTOS DEL PERSONAJE ===");

            personaje.Fue = PedirNumero("Fuerza", personaje.Fue, 1, 100);
            Console.WriteLine($"Modificador: {CalcularModificador(personaje.Fue)}");

            personaje.Des = PedirNumero("Destreza", personaje.Des, 1, 100);
            Console.WriteLine($"Modificador: {CalcularModificador(personaje.Des)}");

            personaje.Con = PedirNumero("Constitución", personaje.Con, 1, 100);
            Console.WriteLine($"Modificador: {CalcularModificador(personaje.Con)}");

            personaje.Int = PedirNumero("Inteligencia", personaje.Int, 1, 100);
            Console.WriteLine($"Modificador: {CalcularModificador(personaje.Int)}");

            personaje.Sab = PedirNumero("Sabiduría", personaje.Sab, 1, 100);
            Console.WriteLine($"Modificador: {CalcularModificador(personaje.Sab)}");

            personaje.Car = PedirNumero("Carisma", personaje.Car, 1, 100);
            Console.WriteLine($"Modificador: {CalcularModificador(personaje.Car)}");

            PrintCentered("\nAtributos actualizados correctamente.");
            Console.ReadKey();
        }

        private void MenuRasgos(Personaje personaje)
        {
            bool salir = false;

            while (!salir)
            {
                Console.Clear();

                var menuRasgos = new string[]
                {
                    "=== GESTIÓN DE RASGOS ===",
                    "",
                    "Tipos de rasgos disponibles:",
                    "1. Acciones",
                    "2. Acciones Adicionales",
                    "3. Acciones Legendarias",
                    "4. Acciones Gratuitas",
                    "5. Acciones de Movimiento",
                    "6. Acciones de Guarida",
                    "7. Reacciones",
                    "8. Pasivas",
                    "9. Resistencias",
                    "10. Auras",
                    "11. Transformaciones",
                    "12. Dotes",
                    "13. Objetos",
                    "14. Sentidos",
                    "15. Hechizos",
                    "16. Volver al menú principal"
                };

                PrintBlockCentered("", menuRasgos);

                Console.Write("\nSeleccione un tipo de rasgo: ");
                var opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        GestionarRasgos(personaje, personaje.Acciones, TipoRasgo.Accion);
                        break;
                    case "2":
                        GestionarRasgos(personaje, personaje.AccionesAdicionales, TipoRasgo.AccionAdicional);
                        break;
                    case "3":
                        GestionarRasgos(personaje, personaje.AccionesLegendarias, TipoRasgo.AccionLegendaria);
                        break;
                    case "4":
                        GestionarRasgos(personaje, personaje.AccionesGratuitas, TipoRasgo.AccionGratuita);
                        break;
                    case "5":
                        GestionarRasgos(personaje, personaje.AccionesMovimiento, TipoRasgo.AccionMovimiento);
                        break;
                    case "6":
                        GestionarRasgos(personaje, personaje.AccionesGuarida, TipoRasgo.AccionGuarida);
                        break;
                    case "7":
                        GestionarRasgos(personaje, personaje.Reacciones, TipoRasgo.Reaccion);
                        break;
                    case "8":
                        GestionarRasgos(personaje, personaje.Pasivas, TipoRasgo.Pasiva);
                        break;
                    case "9":
                        GestionarRasgos(personaje, personaje.Resistencias, TipoRasgo.Resistencia);
                        break;
                    case "10":
                        GestionarRasgos(personaje, personaje.Auras, TipoRasgo.Aura);
                        break;
                    case "11":
                        GestionarRasgos(personaje, personaje.Transformaciones, TipoRasgo.Transformacion);
                        break;
                    case "12":
                        GestionarRasgos(personaje, personaje.Dotes, TipoRasgo.Dote);
                        break;
                    case "13":
                        GestionarRasgos(personaje, personaje.Objetos, TipoRasgo.Objeto);
                        break;
                    case "14":
                        GestionarRasgos(personaje, personaje.Sentidos, TipoRasgo.Sentidos);
                        break;
                    case "15":
                        GestionarHechizos(personaje);
                        break;
                    case "16":
                        salir = true;
                        break;
                    default:
                        PrintCentered("Opción no válida.");
                        Console.ReadKey();
                        break;
                }
            }
        }

        private void GestionarRasgos(Personaje personaje, List<Rasgo> listaRasgos, TipoRasgo tipo)
        {
            bool salir = false;

            while (!salir)
            {
                Console.Clear();
                PrintCentered($"=== RASGOS: {tipo.ToString().ToUpper()} ===");

                if (listaRasgos.Any())
                {
                    Console.WriteLine("\nRasgos actuales:");
                    for (int i = 0; i < listaRasgos.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {listaRasgos[i].Nombre} - {listaRasgos[i].Descripcion}");
                    }
                }
                else
                {
                    Console.WriteLine("\nNo hay rasgos de este tipo añadidos.");
                }

                var menuOpciones = new string[]
                {
                    "\nOpciones:",
                    "1. Añadir nuevo rasgo",
                    "2. Eliminar rasgo",
                    "3. Volver"
                };

                PrintBlockCentered("", menuOpciones);

                Console.Write("\nSeleccione una opción: ");
                var opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Rasgo nuevoRasgo;

                        if (tipo == TipoRasgo.Hechizo)
                        {
                            nuevoRasgo = new Hechizo
                            {
                                Nombre = PedirDato("Nombre del hechizo"),
                                Descripcion = PedirDato("Descripción del hechizo"),
                                Tipo = tipo,
                                NivelHechizo = int.Parse(PedirDato("Nivel del hechizo")),
                                TiempoLanzamiento = PedirDato("Tiempo de lanzamiento"),
                                ComponentesMateriales = PedirDato("Componentes materiales")
                            };
                        }
                        else
                        {
                            nuevoRasgo = new RasgoComun(tipo)
                            {
                                Nombre = PedirDato("Nombre del rasgo"),
                                Descripcion = PedirDato("Descripción del rasgo"),
                                Tipo = tipo
                            };
                        }

                        listaRasgos.Add(nuevoRasgo);
                        personaje.Rasgos.Add(nuevoRasgo);

                        PrintCentered("\nRasgo añadido correctamente.");
                        Console.ReadKey();
                        break;

                    case "2":
                        if (listaRasgos.Any())
                        {
                            for (int i = 0; i < personaje.Rasgos.Count; i++)
                            {
                                Console.WriteLine($"{i + 1}. {personaje.Rasgos[i].Nombre}");
                            }

                            int seleccion = PedirSeleccion("Selecciona un rasgo para eliminar", 1, personaje.Rasgos.Count);
                            personaje.Rasgos.RemoveAt(seleccion - 1);
                            PrintCentered("\nRasgo eliminado correctamente.");
                            Console.ReadKey();
                        }
                        else
                        {
                            PrintCentered("\nNo hay rasgos para eliminar.");
                            Console.ReadKey();
                        }
                        break;
                    case "3":
                        salir = true;
                        break;
                    default:
                        PrintCentered("Opción no válida.");
                        Console.ReadKey();
                        break;
                }
            }
        }
        private void GestionarHechizos(Personaje personaje)
        {
            bool salir = false;

            while (!salir)
            {
                Console.Clear();
                PrintCentered("=== GESTIÓN DE HECHIZOS ===");

                if (personaje.Hechizos.Any())
                {
                    Console.WriteLine("\nHechizos actuales:");
                    for (int i = 0; i < personaje.Hechizos.Count; i++)
                    {
                        var h = personaje.Hechizos[i];
                        Console.WriteLine($"{i + 1}. {h.Nombre} (Nivel {h.NivelHechizo}) - {h.Descripcion}");
                    }
                }
                else
                {
                    Console.WriteLine("\nNo hay hechizos añadidos.");
                }

                var menu = new[]
                {
            "\nOpciones:",
            "1. Añadir hechizo",
            "2. Eliminar hechizo",
            "3. Volver"
        };

                PrintBlockCentered("", menu);
                Console.Write("\nSeleccione una opción: ");
                var opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        var nuevoHechizo = new Hechizo
                        {
                            Nombre = PedirDato("Nombre del hechizo"),
                            Descripcion = PedirDato("Descripción"),
                            NivelHechizo = int.Parse(PedirDato("Nivel del hechizo")),
                            TiempoLanzamiento = PedirDato("Tiempo de lanzamiento"),
                            ComponentesMateriales = PedirDato("Componentes materiales"),
                            Tipo = TipoRasgo.Hechizo
                        };
                        personaje.Hechizos.Add(nuevoHechizo);
                        PrintCentered("\nHechizo añadido correctamente.");
                        Console.ReadKey();
                        break;

                    case "2":
                        if (personaje.Hechizos.Any())
                        {
                            int seleccion = PedirSeleccion("Selecciona un hechizo para eliminar", 1, personaje.Hechizos.Count);
                            personaje.Hechizos.RemoveAt(seleccion - 1);
                            PrintCentered("\nHechizo eliminado correctamente.");
                            Console.ReadKey();
                        }
                        else
                        {
                            PrintCentered("\nNo hay hechizos para eliminar.");
                            Console.ReadKey();
                        }
                        break;

                    case "3":
                        salir = true;
                        break;

                    default:
                        PrintCentered("Opción no válida.");
                        Console.ReadKey();
                        break;
                }
            }
        }

        void VincularCampanyas(Personaje personaje)
        {
            var campanyasDisponibles = _context.Campanyas.ToList();

            if (!campanyasDisponibles.Any())
            {
                PrintCentered("No hay campañas disponibles.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Campañas disponibles:");
            for (int i = 0; i < campanyasDisponibles.Count; i++)
                Console.WriteLine($"{i + 1}. {campanyasDisponibles[i].Nombre}");

            Console.Write("Selecciona la campaña (número): ");
            if (int.TryParse(Console.ReadLine(), out int seleccion) && seleccion >= 1 && seleccion <= campanyasDisponibles.Count)
            {
                var seleccionada = campanyasDisponibles[seleccion - 1];
                personaje.Campanyas.Add(seleccionada);
                PrintCentered($"Campaña '{seleccionada.Nombre}' vinculada al personaje.");
            }
            else
            {
                PrintCentered("Selección inválida.");
            }

            Console.ReadKey();
        }

        private bool ValidarPersonajeCompleto(Personaje personaje)
        {
            return !string.IsNullOrEmpty(personaje.Nombre) &&
                   !string.IsNullOrEmpty(personaje.Clase) &&
                   personaje.Nivel > 0 &&
                   personaje.Vida > 0 &&
                   personaje.Armadura > 0 &&
                   personaje.Fue > 0 &&
                   personaje.Des > 0 &&
                   personaje.Con > 0 &&
                   personaje.Int > 0 &&
                   personaje.Sab > 0 &&
                   personaje.Car > 0;
        }

        /**********************  Métodos auxiliares  *****************************/
        private string PedirDato(string prompt, string valorActual = "")
        {
            Console.Write($"{prompt} {(valorActual != "" ? $"[Actual: {valorActual}] " : "")}: ");
            var input = Console.ReadLine();
            return string.IsNullOrWhiteSpace(input) ? valorActual : input;
        }
        private int PedirNumero(string prompt, int valorActual, int min, int max)
        {
            int valor;
            while (true)
            {
                Console.Write($"{prompt} ({min}-{max}) [Actual: {valorActual}]: ");
                var input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    return valorActual;
                }

                if (int.TryParse(input, out valor))
                {
                    if (valor >= min && valor <= max)
                    {
                        return valor;
                    }
                    Console.WriteLine($"¡Error! Debe ser entre {min} y {max}.");
                }
                else
                {
                    Console.WriteLine("¡Error! Ingrese un número válido.");
                }
            }
        }
        private int PedirSeleccion(string prompt, int min, int max)
        {
            int valor;
            do
            {
                Console.Write($"{prompt} ({min}-{max}): ");
            } while (!int.TryParse(Console.ReadLine(), out valor) || valor < min || valor > max);

            return valor;
        }
        private int CalcularCompetencia(int nivel)
        {
            if (nivel >= 1 && nivel <= 4) return 2;
            else if (nivel >= 5 && nivel <= 8) return 3;
            else if (nivel >= 9 && nivel <= 12) return 4;
            else if (nivel >= 13 && nivel <= 16) return 5;
            else if (nivel >= 17 && nivel <= 20) return 6;
            else if (nivel >= 21 && nivel <= 24) return 7;
            else if (nivel >= 25 && nivel <= 28) return 8;
            else if (nivel >= 29 && nivel <= 32) return 9;
            else if (nivel >= 33 && nivel <= 36) return 10;
            else if (nivel >= 37 && nivel <= 40) return 11;
            else if (nivel >= 41 && nivel <= 44) return 12;
            else if (nivel >= 45 && nivel <= 48) return 13;
            else if (nivel >= 49 && nivel <= 50) return 14;
            else return 2;
        }
        private int CalcularModificador(int valor)
        {
            return (int)Math.Floor((valor - 10) / 2.0);
        }
        void MostrarEstadoPaso(string texto, bool relleno)
        {
            Console.Write($"{texto} ");
            Console.ForegroundColor = relleno ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine(relleno ? "[COMPLETADO]" : "[PENDIENTE]");
            Console.ResetColor();
            // Cambiar el color de fondo y de texto
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.ForegroundColor = ConsoleColor.Yellow;
          

        }
        static void PrintCentered(string texto, bool nuevaLinea = true)
        {
            int consoleWidth = Console.WindowWidth;
            int padding = (consoleWidth - texto.Length) / 2;
            if (padding < 0) padding = 0;
            Console.SetCursorPosition(padding, Console.CursorTop);
            if (nuevaLinea)
                Console.WriteLine(texto);
            else
                Console.Write(texto);
        }
        static void PrintBlockCentered(string titulo, string[] menu)
        {
            int maxLength = menu.Max(l => l.Length);
            int consoleWidth = Console.WindowWidth;
            int blockPadding = (consoleWidth - maxLength) / 2;

            PrintCentered(titulo);

            foreach (var linea in menu)
            {
                Console.SetCursorPosition(blockPadding, Console.CursorTop);
                Console.WriteLine(linea);
            }
        }
        static string ReadLineCentered(string prompt)
        {
            int consoleWidth = Console.WindowWidth;
            int padding = (consoleWidth - prompt.Length) / 2;
            if (padding < 0) padding = 0;

            Console.SetCursorPosition(padding, Console.CursorTop);
            Console.Write(prompt);
            int inputStart = padding + prompt.Length;
            Console.SetCursorPosition(inputStart, Console.CursorTop);

            string? input = Console.ReadLine();
            return input ?? "";
        }
        /*************************************************************************/


        // Método para ver y seleccionar personajes del usuario
        public void VerPersonajes()
        {
            var personajes = _context.Personajes
                .Include(p => p.Campanyas)
                .Where(p => p.UsuarioId == _usuarioActual.Id)
                .ToList();

            if (!personajes.Any())
            {
                Console.Clear();
                PrintCentered("=== TUS PERSONAJES ===");
                PrintCentered("No tienes personajes creados.");
                Console.WriteLine("\nPulsa una tecla para volver...");
                Console.ReadKey();
                return;
            }

            while (true)
            {
                Console.Clear();
                PrintCentered("=== TUS PERSONAJES ===\n");

                // Mostrar lista centrada
                for (int i = 0; i < personajes.Count; i++)
                {
                    PrintCentered($"{i + 1}. {personajes[i].Nombre} (Nivel {personajes[i].Nivel}) - Clase: {personajes[i].Clase}");
                }

                // Prompt centrado
                string prompt = "\nSelecciona un personaje para ver ficha (0 para volver): ";
                Console.SetCursorPosition((Console.WindowWidth - prompt.Length) / 2, Console.CursorTop);
                Console.Write(prompt);

                if (!int.TryParse(Console.ReadLine(), out int sel) || sel < 0 || sel > personajes.Count)
                {
                    PrintCentered("Selección inválida. Pulsa una tecla para continuar...");
                    Console.ReadKey();
                    continue;
                }

                if (sel == 0)
                    break;

                // Mostrar ficha
                var pjSeleccionado = personajes[sel - 1];
                IFichaUI fichaUI = new FichaPersonajeUI();
                fichaUI.MostrarFicha(pjSeleccionado);


                Console.WriteLine("\nPulsa una tecla para volver...");
                Console.ReadKey();
            }
        }

        // Método para ver y seleccionar todos los personajes
        public void VerPersonajesPublicos()
        {
            var personajes = _context.Personajes
                .Include(p => p.Campanyas)
                .ToList();

            if (!personajes.Any())
            {
                Console.Clear();
                PrintCentered("=== PERSONAJES PÚBLICOS ===");
                PrintCentered("No hay personajes creados.");
                Console.WriteLine("\nPulsa una tecla para volver...");
                Console.ReadKey();
                return;
            }

            while (true)
            {
                Console.Clear();
                PrintCentered("=== PERSONAJES PÚBLICOS ===\n");

                for (int i = 0; i < personajes.Count; i++)
                {
                    PrintCentered($"{i + 1}. {personajes[i].Nombre} (Nivel {personajes[i].Nivel}) - Clase: {personajes[i].Clase}");
                }

                string prompt = "\nSelecciona un personaje para ver ficha (0 para volver): ";
                Console.SetCursorPosition((Console.WindowWidth - prompt.Length) / 2, Console.CursorTop);
                Console.Write(prompt);

                if (!int.TryParse(Console.ReadLine(), out int sel) || sel < 0 || sel > personajes.Count)
                {
                    PrintCentered("Selección inválida. Pulsa una tecla para continuar...");
                    Console.ReadKey();
                    continue;
                }

                if (sel == 0)
                    break;

                // Mostrar ficha
                var pjSeleccionado = personajes[sel - 1];
                IFichaUI fichaUI = new FichaPersonajeUI();
                fichaUI.MostrarFicha(pjSeleccionado);


                Console.WriteLine("\nPulsa una tecla para volver...");
                Console.ReadKey();
            }
        }


        // Método para edita un personaje existente
        public void EditarPersonaje()
        {
            var personajes = _context.Personajes
                .Where(p => p.UsuarioId == _usuarioActual.Id)
                .ToList();

            Console.Clear();
            PrintCentered("=== EDITAR PERSONAJE ===");

            if (!personajes.Any())
            {
                PrintCentered("No hay personajes para editar.");
                Console.ReadKey();
                return;
            }

            for (int i = 0; i < personajes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {personajes[i].Nombre} (Nivel {personajes[i].Nivel})");
            }

            int seleccion = PedirSeleccion("Selecciona un personaje para editar", 1, personajes.Count);
            var personajeSeleccionado = personajes[seleccion - 1];

            bool editar = true;
            while (editar)
            {
                Console.Clear();

                var menuEdicion = new string[]
                {
                    $"=== EDITANDO: {personajeSeleccionado.Nombre} ===",
                    "",
                    "1. Editar Datos Básicos",
                    "2. Editar Atributos",
                    "3. Editar Rasgos",
                    "4. Vincular Campañas",
                    "5. Guardar y salir"
                };

                PrintBlockCentered("", menuEdicion);

                Console.Write("Opción: ");
                var opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        EditarDatosBasicos(personajeSeleccionado);
                        break;
                    case "2":
                        EditarAtributos(personajeSeleccionado);
                        break;
                    case "3":
                        MenuRasgos(personajeSeleccionado);
                        break;
                    case "4":
                        VincularCampanyas(personajeSeleccionado);
                        break;
                    case "5":
                        _context.Personajes.Update(personajeSeleccionado);
                        _context.SaveChanges();
                        PrintCentered("✅ Personaje actualizado correctamente.");
                        Console.ReadKey();
                        editar = false;
                        break;
                    default:
                        PrintCentered("Opción no válida.");
                        Console.ReadKey();
                        break;
                }
            }
        }

        // Método para eliminar personajes
        public void EliminarPersonaje()
        {
            var personajes = _context.Personajes
                .Where(p => p.UsuarioId == _usuarioActual.Id)
                .ToList();

            Console.Clear();
            PrintCentered("=== ELIMINAR PERSONAJE ===");

            if (!personajes.Any())
            {
                PrintCentered("No hay personajes para eliminar.");
                Console.ReadKey();
                return;
            }

            for (int i = 0; i < personajes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {personajes[i].Nombre} (Nivel {personajes[i].Nivel})");
            }

            int seleccion = PedirSeleccion("Selecciona un personaje para eliminar", 1, personajes.Count);
            var personajeSeleccionado = personajes[seleccion - 1];

            Console.Write($"¿Estás seguro de que deseas eliminar a '{personajeSeleccionado.Nombre}'? (s/n): ");
            if (Console.ReadLine()?.ToLower() == "s")
            {
                _context.Personajes.Remove(personajeSeleccionado);
                _context.SaveChanges();
                PrintCentered("Personaje eliminado correctamente.");
            }
            else
            {
                PrintCentered("Eliminación cancelada.");
            }

            Console.ReadKey();
        }


        // Método para exportar fichas de personaje a PDF
        public void ExportarPersonajeAPDF()
        {
            var personajes = _context.Personajes
                .Where(p => p.UsuarioId == _usuarioActual.Id)
                .ToList();

            if (!personajes.Any())
            {
                PrintCentered("No tienes personajes para exportar.");
                Console.ReadKey();
                return;
            }

            bool salir = false;
            while (!salir)
            {
                Console.Clear();
                PrintCentered("=== EXPORTAR PERSONAJE A PDF ===");

                // Mostrar lista centrada de personajes
                for (int i = 0; i < personajes.Count; i++)
                {
                    PrintCentered($"{i + 1}. {personajes[i].Nombre} (Nivel {personajes[i].Nivel})");
                }

                // Opción para volver
                PrintCentered($"\n{personajes.Count + 1}. Volver");

                string prompt = "\nSelecciona un personaje para exportar: ";
                Console.SetCursorPosition((Console.WindowWidth - prompt.Length) / 2, Console.CursorTop);
                Console.Write(prompt);

                if (!int.TryParse(Console.ReadLine(), out int seleccion) || seleccion < 1 || seleccion > personajes.Count + 1)
                {
                    PrintCentered("\nSelección inválida. Inténtalo de nuevo.");
                    Console.ReadKey();
                    continue;
                }

                if (seleccion == personajes.Count + 1)
                {
                    salir = true;
                    continue;
                }

                var personaje = personajes[seleccion - 1];

                try
                {
                    // Crear nombre de archivo válido
                    string nombreArchivo = $"Ficha_{personaje.Nombre}_{DateTime.Now:yyyyMMddHHmmss}.pdf";
                    nombreArchivo = string.Join("_", nombreArchivo.Split(Path.GetInvalidFileNameChars()));

                    var pdfExporter = new PdfExporter();
                    string rutaCompleta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), nombreArchivo);

                    pdfExporter.ExportarFichaPersonaje(personaje, rutaCompleta);

                    PrintCentered($"\nFicha de {personaje.Nombre} exportada correctamente a:");
                    PrintCentered(rutaCompleta);
                }
                catch (Exception ex)
                {
                    PrintCentered("\nError al exportar la ficha:");
                    PrintCentered(ex.Message);
                }

                Console.WriteLine("\nPresiona una tecla para continuar...");
                Console.ReadKey();
            }
        }



        /*************************************************************************/
        public void BuscarPersonajesFiltrado()
        {
            Console.Clear();
            var personajes = _context.Personajes.Include(p => p.Campanyas).ToList();

            if (personajes.Count == 0)
            {
                PrintCentered("No hay personajes registrados.");
                Console.ReadKey();
                return;
            }

            PrintCentered("=== BÚSQUEDA DE PERSONAJES ===\n");
            PrintCentered("Puedes buscar por nombre, número o clase.\n");
            string filtro = ReadLineCentered("Introduce el filtro de búsqueda: ").Trim();

            // Buscar por número en la lista
            if (int.TryParse(filtro, out int numero) && numero >= 1 && numero <= personajes.Count)
            {
                var seleccionado = personajes[numero - 1];
                MostrarDetallesPersonaje(seleccionado);
                Console.ReadKey();
                return;
            }

            // Buscar por nombre o clase (ignorar raza)
            var resultados = personajes
                .Where(p =>
                    p.Nombre.Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                    p.Clase.Contains(filtro, StringComparison.OrdinalIgnoreCase))
                .ToList();

            MostrarResultadosPersonajes(resultados);
        }

        private void MostrarDetallesPersonaje(Personaje personaje)
        {
            Console.Clear();
            PrintCentered($"Nombre: {personaje.Nombre}");
            PrintCentered($"Clase: {personaje.Clase}");
            PrintCentered($"Nivel: {personaje.Nivel}");
            PrintCentered($"Campañas vinculadas: {personaje.Campanyas?.Count ?? 0}");
        }

        private void MostrarResultadosPersonajes(List<Personaje> personajes)
        {
            Console.Clear();

            if (personajes.Count == 0)
            {
                PrintCentered("No se encontraron personajes con ese criterio.");
                Console.ReadKey();
                return;
            }

            PrintCentered("Resultados de la búsqueda:\n");

            for (int i = 0; i < personajes.Count; i++)
            {
                var p = personajes[i];
                PrintCentered($"{i + 1}. {p.Nombre} - Nivel {p.Nivel} - {p.Clase}");
            }

            Console.ReadKey();
        }

        /*************************************************************************/


        public List<Personaje> ObtenerTodosPersonajes()
        {
            return _context.Personajes.ToList();
        }

      
    }
}