﻿using System;
using System.Linq;
using ProyectoFinalProgramacion_DNDManager.Data;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using Microsoft.EntityFrameworkCore;

namespace ProyectoFinalProgramacion_DNDManager.Servicios
{
    public class PartidaServ
    {
        private readonly DnDContext _context;

        public PartidaServ(DnDContext context)
        {
            _context = context;
        }

        static void PrintCentered(string texto, bool nuevaLinea = true)
        {
            int consoleWidth = Console.WindowWidth;
            int padding = (consoleWidth - texto.Length) / 2;
            if (padding < 0) padding = 0;
            Console.SetCursorPosition(padding, Console.CursorTop);
            if (nuevaLinea)
                Console.WriteLine(texto);
            else
                Console.Write(texto);
        }
        static string ReadLineCentered(string prompt)
        {
            int consoleWidth = Console.WindowWidth;
            int padding = (consoleWidth - prompt.Length) / 2;
            if (padding < 0) padding = 0;

            Console.SetCursorPosition(padding, Console.CursorTop);
            Console.Write(prompt);
            int inputStart = padding + prompt.Length;
            Console.SetCursorPosition(inputStart, Console.CursorTop);

            string? input = Console.ReadLine();
            return input ?? "";
        }
        

        //Método para crear partidas vinculadas a una campaña
        public void CrearPartida(int campanyaId)
        {
            Console.Clear();
            PrintCentered("=== Crear Nueva Partida ===\n");

            string nombrePartida = ReadLineCentered("Nombre de la partida: ");
            string descripcionPartida = ReadLineCentered("Descripción de la partida: ");

            DateTime fechaPartida;
            while (true)
            {
                string fechaInput = ReadLineCentered("Fecha (yyyy-MM-dd): ");
                if (DateTime.TryParse(fechaInput, out fechaPartida))
                    break;
                PrintCentered("Fecha inválida, inténtalo de nuevo.", true);
            }

            var partida = new Partida
            {
                Nombre = nombrePartida,
                Descripcion = descripcionPartida,
                Fecha = fechaPartida,
                CampanyaId = campanyaId
            };

            try
            {
                _context.Partidas.Add(partida);
                _context.SaveChanges();
                PrintCentered("Partida creada correctamente.");
            }
            catch (Exception ex)
            {
                PrintCentered("[ERROR] No se pudo guardar la partida.");
                PrintCentered("Detalle: " + ex.Message);
            }
        }

        // Método para ver las partidas de una campaña
        public void VerPartidas(int campanyaId)
        {
            Console.Clear();
            var partidas = _context.Partidas.Where(p => p.CampanyaId == campanyaId).ToList();

            if (partidas.Count == 0)
            {
                PrintCentered("No hay partidas para esta campaña.");
                return;
            }

            PrintCentered("Partidas disponibles:\n");
            for (int i = 0; i < partidas.Count; i++)
            {
                var partida = partidas[i];
                PrintCentered($"{i + 1}. {partida.Nombre} - {partida.Fecha:yyyy-MM-dd}");
                PrintCentered($"   Descripción: {partida.Descripcion}");
            }
        }

        // Método para editar partidas
        public void EditarPartida(int campanyaId)
        {
            Console.Clear();
            var partidas = _context.Partidas.Where(p => p.CampanyaId == campanyaId).ToList();

            if (partidas.Count == 0)
            {
                PrintCentered("No hay partidas para esta campaña.");
                return;
            }

            PrintCentered("Partidas disponibles:\n");
            for (int i = 0; i < partidas.Count; i++)
            {
                PrintCentered($"{i + 1}. {partidas[i].Nombre} - {partidas[i].Fecha:yyyy-MM-dd}");
            }

            PrintCentered("\nSeleccione una partida por número: ", false);
            if (!int.TryParse(Console.ReadLine(), out int opcion) || opcion < 1 || opcion > partidas.Count)
            {
                PrintCentered("Opción inválida.");
                return;
            }

            var partidaSeleccionada = partidas[opcion - 1];

            PrintCentered($"Nombre actual: {partidaSeleccionada.Nombre}");
            string nuevoNombre = ReadLineCentered("Nuevo nombre (enter para mantener): ");

            PrintCentered($"Descripción actual: {partidaSeleccionada.Descripcion}");
            string nuevaDescripcion = ReadLineCentered("Nueva descripción (enter para mantener): ");

            PrintCentered($"Fecha actual: {partidaSeleccionada.Fecha:yyyy-MM-dd}");
            DateTime nuevaFecha;
            while (true)
            {
                string fechaInput = ReadLineCentered("Nueva fecha (yyyy-MM-dd) (enter para mantener): ");
                if (string.IsNullOrWhiteSpace(fechaInput))
                {
                    nuevaFecha = partidaSeleccionada.Fecha;
                    break;
                }
                if (DateTime.TryParse(fechaInput, out nuevaFecha))
                {
                    break;
                }
                PrintCentered("Fecha inválida, inténtalo de nuevo.");
            }

            if (!string.IsNullOrWhiteSpace(nuevoNombre)) partidaSeleccionada.Nombre = nuevoNombre;
            if (!string.IsNullOrWhiteSpace(nuevaDescripcion)) partidaSeleccionada.Descripcion = nuevaDescripcion;
            partidaSeleccionada.Fecha = nuevaFecha;

            _context.SaveChanges();
            PrintCentered("Partida actualizada.");
        }

        // Método para elimnar partidas
        public void EliminarPartida(int campanyaId)
        {
            Console.Clear();
            var partidas = _context.Partidas.Where(p => p.CampanyaId == campanyaId).ToList();

            if (partidas.Count == 0)
            {
                PrintCentered("No hay partidas para esta campaña.");
                Console.ReadKey();
                return;
            }

            PrintCentered("Partidas disponibles:\n");
            for (int i = 0; i < partidas.Count; i++)
            {
                PrintCentered($"{i + 1}. {partidas[i].Nombre} - {partidas[i].Fecha:yyyy-MM-dd}");
            }

            PrintCentered("\nSeleccione una partida por número para eliminar: ", false);
            if (!int.TryParse(Console.ReadLine(), out int opcion) || opcion < 1 || opcion > partidas.Count)
            {
                PrintCentered("Opción inválida.");
                Console.ReadKey();
                return;
            }

            var partidaSeleccionada = partidas[opcion - 1];

            PrintCentered($"¿Seguro que quieres eliminar la partida '{partidaSeleccionada.Nombre}'? (s/n): ", false);
            string confirmar = Console.ReadLine()?.Trim().ToLower() ?? "n";
            if (confirmar != "s")
            {
                PrintCentered("Eliminación cancelada.");
                Console.ReadKey();
                return;
            }

            _context.Partidas.Remove(partidaSeleccionada);
            _context.SaveChanges();

            PrintCentered("Partida eliminada correctamente.");
            Console.ReadKey();
        }


        /**************************************************************************/

        public void BuscarPartidasFiltrado()
        {
            Console.Clear();
            var partidas = _context.Partidas.ToList();

            if (partidas.Count == 0)
            {
                PrintCentered("No hay partidas registradas.");
                Console.ReadKey();
                return;
            }

            PrintCentered("=== BÚSQUEDA DE PARTIDAS ===\n");
            PrintCentered("Puedes buscar por nombre, número de lista o año.\n");
            string filtro = ReadLineCentered("Introduce el filtro de búsqueda: ").Trim();

            // Buscar por número
            if (int.TryParse(filtro, out int numero) && numero >= 1 && numero <= partidas.Count)
            {
                var partida = partidas[numero - 1];
                MostrarDetallesPartida(partida);
                Console.ReadKey();
                return;
            }

            // Buscar por año
            if (filtro.Length == 4 && int.TryParse(filtro, out int año))
            {
                var resultadosAño = partidas.Where(p => p.Fecha.Year == año).ToList();
                MostrarResultadosPartidas(resultadosAño);
                return;
            }

            // Buscar por nombre parcial
            var resultadosNombre = partidas
                .Where(p => p.Nombre.Contains(filtro, StringComparison.OrdinalIgnoreCase))
                .ToList();

            MostrarResultadosPartidas(resultadosNombre);
        }

        private void MostrarDetallesPartida(Partida partida)
        {
            Console.Clear();
            PrintCentered($"Nombre: {partida.Nombre}");
            PrintCentered($"Fecha: {partida.Fecha:yyyy-MM-dd}");
            PrintCentered($"Descripción: {partida.Descripcion}");
        }

        private void MostrarResultadosPartidas(List<Partida> partidas)
        {
            Console.Clear();

            if (partidas.Count == 0)
            {
                PrintCentered("No se encontraron partidas con ese criterio.");
                Console.ReadKey();
                return;
            }

            PrintCentered("Resultados de la búsqueda:\n");

            for (int i = 0; i < partidas.Count; i++)
            {
                var p = partidas[i];
                PrintCentered($"{i + 1}. {p.Nombre} - {p.Fecha:yyyy-MM-dd}");
                PrintCentered($"   Descripción: {p.Descripcion}");
            }

            Console.ReadKey();
        }


        /**************************************************************************/


        public List<Partida> ObtenerTodasPartidas()
        {
            return _context.Partidas.ToList();
        }

       

    }

}
