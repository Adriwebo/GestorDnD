﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProyectoFinalProgramacion_DNDManager.Data;
using ProyectoFinalProgramacion_DNDManager.Modelos;

namespace ProyectoFinalProgramacion_DNDManager.Servicios
{
    public class CampanyaServ
    {
        private readonly DnDContext _context;

        public CampanyaServ(DnDContext context)
        {
            _context = context;
        }

        // Método privado para imprimir texto centrado
        static void PrintCentered(string texto, bool nuevaLinea = true)
        {
            int consoleWidth = Console.WindowWidth;
            int padding = (consoleWidth - texto.Length) / 2;
            if (padding < 0) padding = 0;
            Console.SetCursorPosition(padding, Console.CursorTop);
            if (nuevaLinea)
                Console.WriteLine(texto);
            else
                Console.Write(texto);
        }

        // Método para imprimir un prompt centrado y capturar entrada centrada
        static string ReadLineCentered(string prompt)
        {
            int consoleWidth = Console.WindowWidth;
            int padding = (consoleWidth - prompt.Length) / 2;
            if (padding < 0) padding = 0;

            Console.SetCursorPosition(padding, Console.CursorTop);
            Console.Write(prompt);
            // Ahora posicionamos cursor para la entrada justo después del prompt
            int inputStart = padding + prompt.Length;
            Console.SetCursorPosition(inputStart, Console.CursorTop);

            string? input = Console.ReadLine();
            return input ?? "";
        }


        // Crear campaña
        public void CrearCampanya()
        {
            try
            {
                string nombre = ReadLineCentered("Nombre de la campaña: ");
                string descripcion = ReadLineCentered("Descripción: ");

                var campanya = new Campanya
                {
                    Nombre = nombre,
                    Descripcion = descripcion,
                    Personajes = new(),
                    Partidas = new()
                };

                _context.Campanyas.Add(campanya);
                _context.SaveChanges();

                PrintCentered("Campaña creada correctamente.");
            }
            catch (DbUpdateException ex)
            {
                PrintCentered("[ERROR] No se pudo guardar la campaña.");
                PrintCentered("Detalle: " + (ex.InnerException?.Message ?? ex.Message));
            }
        }

        // Listar campañas existentes y sus partidas
        public void VerCampanyasYPartidas()
        {
            var campanyas = _context.Campanyas.Include(c => c.Partidas).ToList();

            if (campanyas.Count == 0)
            {
                PrintCentered("No hay campañas disponibles.");
                Console.ReadKey();
                return;
            }

            PrintCentered("Campañas disponibles:");
            for (int i = 0; i < campanyas.Count; i++)
            {
                PrintCentered($"{i + 1}. {campanyas[i].Nombre}");
            }

            string input = ReadLineCentered("\nSeleccione una campaña por número: ");
            if (!int.TryParse(input, out int opcion) || opcion < 1 || opcion > campanyas.Count)
            {
                PrintCentered("Opción inválida.");
                Console.ReadKey();
                return;
            }

            var campanyaSeleccionada = campanyas[opcion - 1];
            Console.Clear();

            PrintCentered($"=== {campanyaSeleccionada.Nombre} ===");
            PrintCentered("");
            
            PrintCentered("Descripción:");
            PrintCentered(campanyaSeleccionada.Descripcion);
            PrintCentered("");
            PrintCentered($"Partidas en la campaña '{campanyaSeleccionada.Nombre}':");

            if (campanyaSeleccionada.Partidas == null || campanyaSeleccionada.Partidas.Count == 0)
            {
                PrintCentered("No hay partidas para esta campaña.");
                Console.ReadKey();
                return;
            }

            foreach (var partida in campanyaSeleccionada.Partidas)
            {
                PrintCentered($"{partida.Id}- {partida.Nombre}");
            }

            Console.ReadKey();
        }

        // Muestra listado de campañas con su ID y nombre, sin detalles
        public void ListarCampanyasBasico()
        {
            var campanyas = _context.Campanyas.ToList();

            if (campanyas.Count == 0)
            {
                PrintCentered("No hay campañas disponibles.");
                return;
            }

            PrintCentered("Campañas disponibles:");
            foreach (var campanya in campanyas)
            {
                PrintCentered($"ID: {campanya.Id} - {campanya.Nombre}");
            }
        }

        // Editar campañas
        public void EditarCampanya()
        {
            Console.Clear();
            PrintCentered("=== Editar Campaña ===\n");

            ListarCampanyasBasico();

            PrintCentered(""); // línea en blanco

            string idStr = ReadLineCentered("Introduce el ID de la campaña a editar: ");
            if (!int.TryParse(idStr, out int id))
            {
                PrintCentered("ID inválido.");
                return;
            }

            var campanya = _context.Campanyas.FirstOrDefault(c => c.Id == id);
            if (campanya == null)
            {
                PrintCentered("Campaña no encontrada.");
                return;
            }

            PrintCentered("");
            PrintCentered($"Nombre actual: {campanya.Nombre}");
            string nuevoNombre = ReadLineCentered("Nuevo nombre (enter para mantener): ");

            PrintCentered($"Descripción actual: {campanya.Descripcion}");
            string nuevaDesc = ReadLineCentered("Nueva descripción (enter para mantener): ");

            if (!string.IsNullOrWhiteSpace(nuevoNombre)) campanya.Nombre = nuevoNombre;
            if (!string.IsNullOrWhiteSpace(nuevaDesc)) campanya.Descripcion = nuevaDesc;

            _context.SaveChanges();

            PrintCentered("");
            PrintCentered("Campaña actualizada.");
        }



        // Asociar personaje a campaña
        public void AsociarPersonaje(int personajeId)
        {
            VerCampanyasYPartidas();
            string inputId = ReadLineCentered("\nID de la campaña a vincular: ");
            if (!int.TryParse(inputId, out int id)) return;

            var campanya = _context.Campanyas.Include(c => c.Personajes).FirstOrDefault(c => c.Id == id);
            var personaje = _context.Personajes.FirstOrDefault(p => p.Id == personajeId);

            if (campanya == null || personaje == null)
            {
                PrintCentered("Campaña o personaje no encontrado.");
                return;
            }

            campanya.Personajes.Add(personaje);
            _context.SaveChanges();
            PrintCentered("Personaje vinculado a la campaña.");
        }

        // Eliminar campañas solo si no tienen partidas o personajes vinculados
        public bool EliminarCampanya()
        {
            Console.Clear();
            ListarCampanyasBasico();

            string idStr = ReadLineCentered("\nIntroduce el ID de la campaña a eliminar: ");
            if (!int.TryParse(idStr, out int id))
            {
                PrintCentered("ID inválido.");
                return false;
            }

            // Cargamos campaña con partidas y personajes incluidos
            var campanya = _context.Campanyas
                .Include(c => c.Partidas)
                .Include(c => c.Personajes)
                .FirstOrDefault(c => c.Id == id);

            if (campanya == null)
            {
                PrintCentered("Campaña no encontrada.");
                return false;
            }

            if ((campanya.Partidas != null && campanya.Partidas.Count > 0) ||
                (campanya.Personajes != null && campanya.Personajes.Count > 0))
            {
                PrintCentered("[ERROR] No se puede eliminar la campaña porque tiene partidas o personajes vinculados.");
                Console.ReadKey();
                return false;
            }

            _context.Campanyas.Remove(campanya);
            _context.SaveChanges();

            PrintCentered("[ÉXITO] Campaña eliminada correctamente.");
            Console.ReadKey();
            return true;
        }

        /**************************************************************************/

        public void BuscarCampanyasFiltrado()
        {
            Console.Clear();
            var campanyas = _context.Campanyas.Include(c => c.Partidas).ToList();

            if (campanyas.Count == 0)
            {
                PrintCentered("No hay campañas registradas.");
                Console.ReadKey();
                return;
            }

            PrintCentered("=== BÚSQUEDA DE CAMPAÑAS ===\n");
            PrintCentered("Puedes buscar por nombre, número o texto en la descripción.\n");
            string filtro = ReadLineCentered("Introduce el filtro de búsqueda: ").Trim();

            // Buscar por número
            if (int.TryParse(filtro, out int numero) && numero >= 1 && numero <= campanyas.Count)
            {
                var seleccionada = campanyas[numero - 1];
                MostrarDetallesCampanya(seleccionada);
                Console.ReadKey();
                return;
            }

            // Buscar por nombre o descripción
            var resultados = campanyas
                .Where(c =>
                    c.Nombre.Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                    c.Descripcion.Contains(filtro, StringComparison.OrdinalIgnoreCase))
                .ToList();

            MostrarResultadosCampanyas(resultados);
        }

        private void MostrarDetallesCampanya(Campanya campanya)
        {
            Console.Clear();
            PrintCentered($"Nombre: {campanya.Nombre}");
            PrintCentered($"Descripción: {campanya.Descripcion}");
            PrintCentered($"Total de partidas: {campanya.Partidas?.Count ?? 0}");
        }

        private void MostrarResultadosCampanyas(List<Campanya> campanyas)
        {
            Console.Clear();

            if (campanyas.Count == 0)
            {
                PrintCentered("No se encontraron campañas con ese criterio.");
                Console.ReadKey();
                return;
            }

            PrintCentered("Resultados de la búsqueda:\n");

            for (int i = 0; i < campanyas.Count; i++)
            {
                var c = campanyas[i];
                PrintCentered($"{i + 1}. {c.Nombre} - {c.Descripcion}");
                PrintCentered($"   Partidas: {c.Partidas?.Count ?? 0}");
            }

            Console.ReadKey();
        }


        /**************************************************************************/

        public List<Campanya> ObtenerTodasCampanyas()
        {
            return _context.Campanyas.ToList();
        }

        
    }
}
