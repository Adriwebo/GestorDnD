﻿using System;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using System.Linq;

namespace ProyectoFinalProgramacion_DNDManager.UI
{
    public  class FichaPersonajeUI : IFichaUI
    {
        public void MostrarFicha(Personaje p)
        {
            Console.Clear();

            int width = 60;  // Ancho fijo para centrar los bloques
            string linea = new string('═', width);

            // Método local para centrar texto dado ancho
            string CenterText(string text)
            {
                if (text.Length >= width) return text;
                int leftPadding = (width - text.Length) / 2;
                return new string(' ', leftPadding) + text;
            }

            void PrintCenteredLine(string text)
            {
                Console.WriteLine(CenterText(text));
            }

            // Título con borde
            PrintCenteredLine($"╔{linea}╗");
            PrintCenteredLine($"║{CenterText("FICHA DE PERSONAJE: " + p.Nombre.ToUpper()).Trim()}║");
            PrintCenteredLine($"╚{linea}╝\n");

            // Datos básicos
            PrintCenteredLine($"Clase y Nivel: {p.Clase} Nivel {p.Nivel}");
            PrintCenteredLine($"Descripción: {p.Descripcion}\n");

            // Vida, CA, Competencia
            string vidaLine = $" VIDA: {p.Vida,-3}   CA: {p.Armadura,-3}   Competencia: {p.Competencia,-3} ";
            PrintCenteredLine($"╔{new string('═', vidaLine.Length)}╗");
            PrintCenteredLine($"║{vidaLine}║");
            PrintCenteredLine($"╚{new string('═', vidaLine.Length)}╝\n");

            // Estadísticas
            string statsHeader = "FUE  | DES  | CON  | INT  | SAB  | CAR";
            string statsValues = $"{p.Fue,-4}| {p.Des,-4}| {p.Con,-4}| {p.Int,-4}| {p.Sab,-4}| {p.Car,-4}";

            PrintCenteredLine($"╔{new string('═', statsHeader.Length)}╗");
            PrintCenteredLine($"║{statsHeader}║");
            PrintCenteredLine($"║{new string('-', statsHeader.Length)}║");
            PrintCenteredLine($"║{statsValues}║");
            PrintCenteredLine($"╚{new string('═', statsHeader.Length)}╝\n");

            // Método para imprimir lista de rasgos centrada
            void ImprimirSeccion(string titulo, System.Collections.Generic.List<Rasgo> lista)
            {
                PrintCenteredLine($"-- {titulo.ToUpper()} --");

                if (lista == null || lista.Count == 0)
                {
                    PrintCenteredLine("(Ninguno)\n");
                    return;
                }

                foreach (var r in lista)
                {
                    string desc = r.Descripcion.Length > 50 ? r.Descripcion.Substring(0, 47) + "..." : r.Descripcion;
                    string lineaRasgo = $"* {r.Nombre}: {desc}";
                    PrintCenteredLine(lineaRasgo);
                }
                Console.WriteLine();
            }

            // Imprimir todas las secciones
            ImprimirSeccion("Acciones", p.Acciones);
            ImprimirSeccion("Acciones adicionales", p.AccionesAdicionales);
            ImprimirSeccion("Acciones legendarias", p.AccionesLegendarias);
            ImprimirSeccion("Acciones gratuitas", p.AccionesGratuitas);
            ImprimirSeccion("Acciones de movimiento", p.AccionesMovimiento);
            ImprimirSeccion("Acciones de guarida", p.AccionesGuarida); 
            ImprimirSeccion("Reacciones", p.Reacciones);
            ImprimirSeccion("Pasivas", p.Pasivas);
            ImprimirSeccion("Resistencias", p.Resistencias);
            ImprimirSeccion("Auras", p.Auras);
            ImprimirSeccion("Transformaciones", p.Transformaciones);
            ImprimirSeccion("Dotes", p.Dotes);
            ImprimirSeccion("Objetos", p.Objetos);
            ImprimirSeccion("Sentidos", p.Sentidos);

            // Mostrar sección de hechizos (tipo específico)
            PrintCenteredLine("-- HECHIZOS --");

            if (p.Hechizos == null || !p.Hechizos.Any())
            {
                PrintCenteredLine("(Ninguno)\n");
            }
            else
            {
                foreach (var hechizo in p.Hechizos)
                {
                    string desc = hechizo.Descripcion.Length > 40 ? hechizo.Descripcion.Substring(0, 37) + "..." : hechizo.Descripcion;
                    PrintCenteredLine($"* {hechizo.Nombre} (Nivel {hechizo.NivelHechizo})");
                    PrintCenteredLine($"  Tiempo: {hechizo.TiempoLanzamiento} | Componentes: {hechizo.ComponentesMateriales}");
                    PrintCenteredLine($"  {desc}\n");
                }
            }


            // Campañas
            PrintCenteredLine("-- CAMPAÑAS EN LAS QUE PARTICIPA --");
            if (p.Campanyas == null || !p.Campanyas.Any())
            {
                PrintCenteredLine("(Ninguna)\n");
            }
            else
            {
                foreach (var c in p.Campanyas)
                {
                    PrintCenteredLine("* " + c.Nombre);
                }
                Console.WriteLine();
            }

            PrintCenteredLine(new string('─', width));
            PrintCenteredLine("Pulsa cualquier tecla para volver...");
            Console.ReadKey();
        }
    }
}
