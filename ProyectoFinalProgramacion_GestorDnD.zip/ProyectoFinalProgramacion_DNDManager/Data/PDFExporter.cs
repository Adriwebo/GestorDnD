﻿using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using System.IO;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

public class PdfExporter
{
    public void ExportarFichaPersonaje(Personaje p, string rutaArchivo)
    {
        var document = new PdfDocument();
        document.Info.Title = $"Ficha de Personaje - {p.Nombre}";

        var page = document.AddPage();
        var gfx = XGraphics.FromPdfPage(page);

        // Fuentes
        var fontTitle = new XFont("Verdana", 18, XFontStyle.Bold);
        var fontHeader = new XFont("Verdana", 14, XFontStyle.Bold);
        var fontSubHeader = new XFont("Verdana", 12, XFontStyle.BoldItalic);
        var fontNormal = new XFont("Verdana", 10, XFontStyle.Regular);

        int y = 40;
        int margenX = 40;
        int lineHeight = 18;

        void DrawLine(string text, XFont font, int xOffset = 0)
        {
            gfx.DrawString(text, font, XBrushes.Black, new XPoint(margenX + xOffset, y));
            y += lineHeight;
        }

        void DrawWrappedText(string text, XFont font, int maxWidth)
        {
            var words = text.Split(' ');
            string line = "";
            foreach (var word in words)
            {
                var testLine = line + (line == "" ? "" : " ") + word;
                var size = gfx.MeasureString(testLine, font);
                if (size.Width > maxWidth)
                {
                    DrawLine(line, font);
                    line = word;
                }
                else
                {
                    line = testLine;
                }
            }
            if (line != "")
                DrawLine(line, font);
        }

        // Título
        gfx.DrawString($"Ficha de Personaje: {p.Nombre}", fontTitle, XBrushes.Black, new XRect(0, y, page.Width, lineHeight), XStringFormats.TopCenter);
        y += lineHeight + 10;

        // Datos básicos
        DrawLine($"Clase y Nivel: {p.Clase} Nivel {p.Nivel}", fontNormal);
        DrawWrappedText($"Descripción: {p.Descripcion}", fontNormal, (int)page.Width - 2 * margenX);
        y += 10;

        // Vida, CA, Competencia
        DrawLine($"VIDA: {p.Vida}   CA: {p.Armadura}   Competencia: {p.Competencia}", fontNormal);
        y += 10;

        // Estadísticas
        DrawLine("Estadísticas:", fontHeader);
        DrawLine($"FUE: {p.Fue} | DES: {p.Des} | CON: {p.Con} | INT: {p.Int} | SAB: {p.Sab} | CAR: {p.Car}", fontNormal);
        y += 10;

        // Función para imprimir listas de rasgos
        void DibujarSeccion(string titulo, System.Collections.Generic.List<Rasgo> lista)
        {
            DrawLine(titulo.ToUpper(), fontHeader);
            if (lista == null || lista.Count == 0)
            {
                DrawLine("(Ninguno)", fontNormal);
                y += 5;
                return;
            }
            foreach (var r in lista)
            {
                var desc = r.Descripcion.Length > 100 ? r.Descripcion.Substring(0, 97) + "..." : r.Descripcion;
                DrawLine($"- {r.Nombre}: ", fontSubHeader);
                DrawWrappedText(desc, fontNormal, (int)page.Width - margenX * 2 - 20);
                y += 5;
            }
            y += 10;
        }

        // Secciones de rasgos (igual que consola)
        DibujarSeccion("Acciones", p.Acciones);
        DibujarSeccion("Acciones adicionales", p.AccionesAdicionales);
        DibujarSeccion("Acciones legendarias", p.AccionesLegendarias);
        DibujarSeccion("Acciones gratuitas", p.AccionesGratuitas);
        DibujarSeccion("Acciones de movimiento", p.AccionesMovimiento);
        DibujarSeccion("Acciones de guarida", p.AccionesGuarida);
        DibujarSeccion("Reacciones", p.Reacciones);
        DibujarSeccion("Pasivas", p.Pasivas);
        DibujarSeccion("Resistencias", p.Resistencias);
        DibujarSeccion("Auras", p.Auras);
        DibujarSeccion("Transformaciones", p.Transformaciones);
        DibujarSeccion("Dotes", p.Dotes);
        DibujarSeccion("Objetos", p.Objetos);
        DibujarSeccion("Sentidos", p.Sentidos);

        // Hechizos (más detallado)
        DrawLine("HECHIZOS", fontHeader);
        if (p.Hechizos == null || !p.Hechizos.Any())
        {
            DrawLine("(Ninguno)", fontNormal);
        }
        else
        {
            foreach (var hechizo in p.Hechizos)
            {
                DrawLine($"- {hechizo.Nombre} (Nivel {hechizo.NivelHechizo})", fontSubHeader);
                DrawLine($"  Tiempo de lanzamiento: {hechizo.TiempoLanzamiento}", fontNormal, 20);
                DrawLine($"  Componentes: {hechizo.ComponentesMateriales}", fontNormal, 20);
                DrawWrappedText($"  {hechizo.Descripcion}", fontNormal, (int)page.Width - margenX * 2 - 20);
                y += 5;
            }
        }

        y += 10;

        // Campañas
        DrawLine("CAMPAÑAS EN LAS QUE PARTICIPA", fontHeader);
        if (p.Campanyas == null || !p.Campanyas.Any())
        {
            DrawLine("(Ninguna)", fontNormal);
        }
        else
        {
            foreach (var c in p.Campanyas)
            {
                DrawLine($"- {c.Nombre}", fontNormal);
            }
        }

        // Guardar documento en archivo
        using (var stream = new FileStream(rutaArchivo, FileMode.Create))
        {
            document.Save(stream);
        }
    }
}
