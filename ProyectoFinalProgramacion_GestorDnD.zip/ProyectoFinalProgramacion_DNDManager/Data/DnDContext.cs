﻿using Microsoft.EntityFrameworkCore;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.Data
{
    public class DnDContext : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Personaje> Personajes { get; set; }
        public DbSet<Campanya> Campanyas { get; set; }
        public DbSet<Partida> Partidas { get; set; }

        public DbSet<Rasgo> Rasgos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=gestor_dnd.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configura la relación muchos-a-muchos sin entidad intermedia explícita
            modelBuilder.Entity<Campanya>()
                .HasMany(c => c.Personajes)
                .WithMany(p => p.Campanyas);

            modelBuilder.Entity<Rasgo>()
                .HasDiscriminator<TipoRasgo>("Tipo")
                .HasValue<RasgoComun>(TipoRasgo.Pasiva)  // Aqui explico manualmente al EF Core que comprenda la herencia
                .HasValue<Hechizo>(TipoRasgo.Hechizo);


        }
    }
}
