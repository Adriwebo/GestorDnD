﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using ProyectoFinalProgramacion_DNDManager.Modelos;

namespace ProyectoFinalProgramacion_DNDManager.Data
{
    public static class AlmacenamientoJson
    {
        private static JsonSerializerOptions opciones = new JsonSerializerOptions
        {
            WriteIndented = true,
            ReferenceHandler = ReferenceHandler.Preserve
        };

        private static string ObtenerCarpetaJson()
        {
            string proyectoBase = Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory).Parent.Parent.FullName;
            string carpetaBase = Path.Combine(proyectoBase, "Data", "jsons");
            if (!Directory.Exists(carpetaBase))
            {
                Directory.CreateDirectory(carpetaBase);
            }
            return carpetaBase;
        }


        // Guarda lista de usuarios en un archivo JSON
        public static void GuardarUsuarios(List<Usuario> usuarios)
        {
            string rutaArchivo = Path.Combine(ObtenerCarpetaJson(), "usuarios.json");
            string json = JsonSerializer.Serialize(usuarios, opciones);
            File.WriteAllText(rutaArchivo, json);
        }


        // Guarda lista de personajes en un archivo JSON
        public static void GuardarPersonajes(List<Personaje> personajes)
        {
            string rutaArchivo = Path.Combine(ObtenerCarpetaJson(), "personajes.json");
            string json = JsonSerializer.Serialize(personajes, opciones);
            File.WriteAllText(rutaArchivo, json);
        }


        // Guarda lista de campañas en un archivo JSON
        public static void GuardarCampanyas(List<Campanya> campanyas)
        {
            string rutaArchivo = Path.Combine(ObtenerCarpetaJson(), "campanyas.json");
            string json = JsonSerializer.Serialize(campanyas, opciones);
            File.WriteAllText(rutaArchivo, json);
        }


        // Guarda lista de partidas en un archivo JSON
        public static void GuardarPartidas(List<Partida> partidas)
        {
            string rutaArchivo = Path.Combine(ObtenerCarpetaJson(), "partidas.json");
            string json = JsonSerializer.Serialize(partidas, opciones);
            File.WriteAllText(rutaArchivo, json);
        }



    }
}
