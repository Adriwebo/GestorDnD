﻿using ProyectoFinalProgramacion_DNDManager.Data;
using ProyectoFinalProgramacion_DNDManager.Modelos;
using ProyectoFinalProgramacion_DNDManager.Servicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public class Usuario
    {
        public int Id { get; set; } // Clave primaria para el modelo relacional
        public string Nombre { get; set; } = "";
        public string Contraseña { get; set; } = "";

        //Relacion uno-a-muchos con Personaje
        public List<Personaje> Personajes { get; set; } = new();
    }
}


