﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public class Personaje
    {
        public Personaje() { } 

        public Personaje(string nombre, string clase, int nivel, string descripcion, int vida, int armadura, int fue,
    int des, int con, int @int, int sab, int car, List<Rasgo> acciones, List<Rasgo> accionesAdicionales, List<Rasgo> accionesLegendarias, List<Rasgo> accionesGratuitas,
    List<Rasgo> accionesMovimiento, List<Rasgo> accionesGuarida, List<Rasgo> reacciones, List<Rasgo> pasivas, List<Rasgo> resistencias, List<Rasgo> auras, List<Rasgo> transformaciones,
    List<Rasgo> dotes, List<Rasgo> objetos, List<Rasgo> sentidos, List<Rasgo> hechizos, int usuarioId, List<Campanya> campanyas, List<Rasgo> rasgos)
        {
            Nombre = nombre;
            Clase = clase;
            Nivel = nivel;
            Descripcion = descripcion;
            Vida = vida;
            Armadura = armadura;
            Fue = fue;
            Des = des;
            Con = con;
            Int = @int;
            Sab = sab;
            Car = car;
            Acciones = acciones;
            AccionesAdicionales = accionesAdicionales;
            AccionesLegendarias = accionesLegendarias;
            AccionesGratuitas = accionesGratuitas;
            AccionesMovimiento = accionesMovimiento;
            AccionesGuarida = accionesGuarida;
            Reacciones = reacciones;
            Pasivas = pasivas;
            Resistencias = resistencias;
            Auras = auras;
            Transformaciones = transformaciones;
            Dotes = dotes;
            Objetos = objetos;
            Sentidos = sentidos;
            UsuarioId = usuarioId;
            Campanyas = campanyas;
            Rasgos = rasgos;
        }


        // Propiedades básicas del personaje
        public int Id { get; set; } // Clave primaria para el modelo relacional
        public string Nombre { get; set; } = "";  // Nombre del personaje
        public string Clase { get; set; } = "";  // Clase del personaje (Monje, Guerrero, etc.)
        public int Nivel { get; set; }  // Nivel del personaje
        public string Descripcion { get; set; } = "";  // Descripción general del personaje

        // Propiedades de estadísticas
        public int Vida { get; set; }  // Puntos de vida del personaje
        public int Armadura { get; set; }  // Clase de armadura (CA)
        public int Competencia { get; set; }  // Competencia (bonificación de competencia según el nivel)

        // Estadísticas del personaje
        public int Fue { get; set; } // Fuerza
        public int Des { get; set; } // Destreza
        public int Con { get; set; } // Constitución
        public int Int { get; set; } // Inteligencia
        public int Sab { get; set; } // Sabiduría
        public int Car { get; set; } // Carisma

        // Propiedades de habilidades y rasgos
        public List<Rasgo> Acciones { get; set; } = new();             // Acciones estándar
        public List<Rasgo> AccionesAdicionales { get; set; } = new();  // Acciones adicionales
        public List<Rasgo> AccionesLegendarias { get; set; } = new();  // Acciones legendarias
        public List<Rasgo> AccionesGratuitas { get; set; } = new();    // Acciones gratuitas
        public List<Rasgo> AccionesMovimiento { get; set; } = new();   // Acciones de movimiento
        public List<Rasgo> AccionesGuarida { get; set; } = new();      // Acciones de guarida
        public List<Rasgo> Reacciones { get; set; } = new();           // Reacciones
        public List<Rasgo> Pasivas { get; set; } = new();              // Habilidades pasivas
        public List<Rasgo> Resistencias { get; set; } = new();         // Resistencias
        public List<Rasgo> Auras { get; set; } = new();                // Auras
        public List<Rasgo> Transformaciones { get; set; } = new();     // Transformaciones
        public List<Rasgo> Dotes { get; set; } = new();                // Dotes
        public List<Rasgo> Objetos { get; set; } = new();              // Objetos
        public List<Rasgo> Sentidos { get; set; } = new();             // Sentidos

        // Relación con el usuario que crea al personaje (relación uno a muchos)
        public int UsuarioId { get; set; }  // Clave foránea al modelo de Usuario
        public Usuario Usuario { get; set; } = null!;  // Usuario que ha creado el personaje

        // Relación muchos a muchos con campañas (un personaje puede estar en varias campañas)
        public List<Campanya> Campanyas { get; set; } = new();  // Lista de campañas a las que pertenece el personaje

        // Relación muchos a muchos con Rasgos/Habilidades (un personaje puede tener muchos rasgos)
        public List<Rasgo> Rasgos { get; set; } = new();  // Lista de rasgos asociados al personaje

        // Relación muchos a muchos con Hechizos 
        public List<Hechizo> Hechizos { get; set; } = new(); // Lista de hechizos asociados al personaje

    }
}


