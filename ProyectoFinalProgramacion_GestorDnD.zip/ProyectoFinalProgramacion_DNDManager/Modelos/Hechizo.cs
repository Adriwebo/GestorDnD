﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public class Hechizo : Rasgo
    {
        public int NivelHechizo { get; set; }
        public string TiempoLanzamiento { get; set; } = "";
        public string ComponentesMateriales { get; set; } = "";

        public Hechizo()
        {
            Tipo = TipoRasgo.Hechizo;
        }
    }
}
