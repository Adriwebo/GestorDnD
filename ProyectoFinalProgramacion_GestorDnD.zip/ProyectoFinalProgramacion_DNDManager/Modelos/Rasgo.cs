﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public enum TipoRasgo
    {
        Accion,
        AccionAdicional,
        AccionLegendaria,
        AccionGratuita,
        AccionMovimiento,
        AccionGuarida,
        Reaccion,
        Pasiva,
        Resistencia,
        Aura,
        Transformacion,
        Dote,
        Objeto,
        Sentidos,
        Hechizo
    }

    public abstract class Rasgo
    {
        public int Id { get; set; } // Clave primaria para el rasgo
        public string Nombre { get; set; } = ""; // Nombre del rasgo (ej. "Golpe Aturdidor")
        public string Descripcion { get; set; } = ""; // Descripción del rasgo
        public TipoRasgo Tipo { get; set; } // Tipo del rasgo (Acción, Reacción, etc.)

    }
}
