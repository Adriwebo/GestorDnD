﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public class RasgoComun : Rasgo
    {
        public RasgoComun(TipoRasgo tipo)
        {
        }
    }
}