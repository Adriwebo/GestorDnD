﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public class Partida
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = null!;
        public string? Descripcion { get; set; }
        public DateTime Fecha { get; set; }  
        public int CampanyaId { get; set; }
        public Campanya? Campanya { get; set; }
    }
}
