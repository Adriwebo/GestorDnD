﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalProgramacion_DNDManager.Modelos
{
    public class Campanya
    {
        public int Id { get; set; } // Clave primaria de campaña para el modelo relacional
        public string Nombre { get; set; } = "";
        public string Descripcion { get; set; } = "";

        public List<Partida> Partidas { get; set; } = new();

        public List<Personaje> Personajes { get; set; } = new();
    }
}
